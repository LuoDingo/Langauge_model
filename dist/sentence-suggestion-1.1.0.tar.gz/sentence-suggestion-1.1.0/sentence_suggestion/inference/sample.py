from inference import SearchSpace

space = SearchSpace(
            input_vocab_path='MASKED_TEXT.Field',
            output_vocab_path='TARGET_TEXT.Field',
            model_path='seq2seq-multilayer-gru.pt',
            device_type='cpu',
            sentence_candidates_path='space_sample.csv',
        )

print(space.search_kbest(keywords='how many tickets you ?', k=3))

print(space.search_kbest(keywords='what theater you go ?', k=3))
